Hotfix 407828-1 should be installed on Sitecore 9.3.0 rev. 003498.

This hotfix replaces existing files, should be installed via package installation wizard.
When asked what to do, allow the installation wizard to overwrite the existing files.

The following binary files will be overwritten:

�     /bin/Sitecore.ExperienceEditor.dll
�     /bin/Sitecore.ExperienceEditor.Speak.dll
�     /bin/Sitecore.ExperienceEditor.Speak.Ribbon.dll